<?php

defined('MBQ_IN_IT') or exit;

/**
 * session handle
 */
Class MbqSession {
    
    public function __construct() {
    }
  
}
