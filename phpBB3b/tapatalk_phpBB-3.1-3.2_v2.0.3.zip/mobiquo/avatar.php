<?php
global $tapatalk_cmd;
$tapatalk_cmd = 'avatar';
require_once('mobiquo.php');
